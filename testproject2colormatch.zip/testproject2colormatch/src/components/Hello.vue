<template>
  <view>
    <text>{{ data }}</text>
  </view>
</template>

<script>
export default {
  data() {
    return {
      data: "Hello.vue DATA!",
    };
  },
};
</script>

<style>
</style>