<template>
  <view>
    <text> {{ title }} </text>
  </view>
</template>

<script>
export default {
  data() {
    return {
      title: "Screen2 Title",
    };
  },
};
</script>

<style>
</style>