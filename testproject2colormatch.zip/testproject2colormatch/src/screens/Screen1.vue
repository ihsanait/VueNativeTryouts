<template>
  <view class="container">
    <text>{{ cameraText }}</text>
    <text
      v-bind:style="{
        backgroundColor: hex,
        padding: '5%',
        height: '20%',
        fontSize: 50,
        textAlign: 'center'
      }"
    > {{hex}} </text>
    <!-- <image
      id="imgg"
      :style="{ width: 200, height: 200 }"
      :source="{ uri: imuri }"
    /> -->
    <camera
      class="container"
      :type="this.type"
      :ref="setCameraRef(ref)"
      :onCameraReady="cameraReady"
    />
    <button title="ÇEK" :on-press="cameraOnPress"></button>
    <status-bar :background-color="hex" bar-style="light-content" />
  </view>
</template>

<script>
import * as Permissions from "expo-permissions";
import { Camera } from "expo-camera";
import axios from "axios";
import AppVue from "../../App.vue";
import * as FileSystem from "expo-file-system";

export default {
  data: function () {
    return {
      hasCameraPermission: false,
      type: Camera.Constants.Type.back,
      camera: new Camera(),
      hex: "#EE0055",
      // imuri: "https://facebook.github.io/react-native/docs/assets/favicon.png",
      cameraText: "camera not ready!",
    };
  },
  mounted: function () {
    Permissions.askAsync(Permissions.CAMERA)
      .then((status) => {
        hasCameraPermission = status.status == "granted" ? true : false;
      })
      .catch((err) => {
        console.log(err);
      });
  },

  components: { Camera },
  computed: {
    getHex() {
      return "background-color:#EE0055;";
    },
  },
  methods: {
    cameraReady() {
      this.cameraText = "Camera is ready!";
      console.log("Camera is ready!");
      console.log(this.hex);
    },
    async cameraOnPress() {
      var data = await this.camera.takePictureAsync();
      console.log(data.uri);

      let response = await FileSystem.uploadAsync(
        "http://192.168.2.42:5101/api/test/up2",
        data.uri,
        {
          headers: { ContentType: "image/jpeg" },
        }
      );

      this.hex = response.body;

      // var formData = new FormData();
      // formData.append("DataValue", this.imuri);

      // await axios({
      //   method: "post",
      //   url: "http://192.168.2.42:5101/api/test/up3",
      //   data: formData,
      //   headers: { "Content-Type": "multipart/form-data" },
      // })
      //   .then(function (response) {
      //     alert(response.data);
      //   })
      //   .catch(function (err) {
      //     alert("err:" + err);
      //   });
    },
    getTest() {
      axios
        .get("https://apicore.ait.com.tr/api/test/helloworld")
        .then(function (response) {
          // handle success
          console.log(response.data);
        });
    },
    setCameraRef(ref) {
      this.camera = ref;
    },
  },
};
</script>

<style>
.container {
  flex: 1;
}
.text-color-primary {
  color: blue;
}
</style>